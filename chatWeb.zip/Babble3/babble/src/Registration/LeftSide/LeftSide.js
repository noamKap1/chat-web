import './LeftSide.css'

function LeftSide() {
    return (
        <>
            {/* Left side of the page */}
            <div id="background"></div>
            <div id="image"></div>
        </>
    );
}

export default LeftSide;